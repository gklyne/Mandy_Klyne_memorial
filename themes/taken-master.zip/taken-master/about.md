---
layout: page
title: About
permalink: /about/
---

Taken is a two column minimalist Jekyll theme.

Taken is based on [chapter tumblr theme.](http://theme-chapter.tumblr.com/)

You can fork taken from [here.](https://github.com/vfalanis/taken)
