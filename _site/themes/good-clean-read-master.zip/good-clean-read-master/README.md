This is as Jekyll theme built to make single page websites, articles, or literary masterpieces readable anywhere.

### [Demo and Documentation](https://adueck.github.io/good-clean-read)

Built on top of <a href="http://chibicode.github.io/solo">Solo</a>, by [Shu Uesugi](https://github.com/chibicode)
